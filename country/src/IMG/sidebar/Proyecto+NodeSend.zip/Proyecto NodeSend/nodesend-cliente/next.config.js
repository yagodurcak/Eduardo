module.exports = {
    env: {
        backendURL: 'http://localhost:4000',
        frontendURL: 'http://localhost:3000'
    }
}